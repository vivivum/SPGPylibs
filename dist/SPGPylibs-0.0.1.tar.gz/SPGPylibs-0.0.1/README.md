# P-tools

Python libraries for PHI and TuMAG proyects

FP-tools are pythons tools for simulating etalons

PD-tools are Phase-Diversity image reconstruction programs for TuMAG

